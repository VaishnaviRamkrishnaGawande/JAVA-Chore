
public class TestAccount {

	public static void main(String[] args) {
		Account ac1=new Account("xxxx",34567,"Saving");
		System.out.println(ac1);

		Account ac2=new Account("yyyyyy",34555,"Saving");
		System.out.println(ac2);
	}

}
